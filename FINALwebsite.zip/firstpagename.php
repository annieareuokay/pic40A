#!/usr/local/bin/php
<?php
if($_POST){
	$username = $_POST['username'];
}
// if(isset($_POST['username'])){
// 	header("location: FINALpage2.php");}
?> 